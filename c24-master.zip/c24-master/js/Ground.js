class Ground {
  constructor(x, y, width, height) {
    var options ={
      isStatic : true
    }
  };

  display(){
  }
}
